#' @useDynLib singlearm
#' @importFrom Rcpp sourceCpp
NULL
